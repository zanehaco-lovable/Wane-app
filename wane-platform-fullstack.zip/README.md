# Wane · وانە — Full-stack Kurdish learning platform

Monorepo: real backend (Node/Express + PostgreSQL), 6-language frontend, and a
PWA mobile build. One command brings up the whole stack.

```bash
cp .env.example .env        # optional: add provider keys
docker compose up --build
# frontend  → http://localhost:8080         (desktop)
#             http://localhost:8080/mobile.html   (phone PWA)
#             http://localhost:8080/verify.html   (public certificate check)
# backend   → http://localhost:4000/api/health
```
The backend auto-seeds demo data on first boot (users, levels, question bank,
grammar rules, phonetics, semantic groups).

## Demo accounts
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@wane.academy | admin123 |
| Teacher | teacher@wane.academy | teacher123 |
| Agent | agent@wane.academy | agent123 |
| Student | student@wane.academy | student123 |

## Honest status of each spec feature
| Feature | State | Notes |
|---------|-------|-------|
| Auth + bcrypt + JWT | REAL | `routes/auth.routes.js`, `middleware/auth.js` |
| RBAC (admin gate) | REAL | `requireRole('ADMIN')` on the admin router |
| PostgreSQL schema | REAL | `db/schema.sql` (incl. semantic_groups, certificates) |
| Progression tree + gatekeeper | REAL | `services/progression.js` (≥80% unlocks next, one transaction) |
| Tri-component exam (Reading/Writing/Speaking) | REAL | weighted-random generation, instant reading grade |
| Writing grade via RAG | REAL engine, LLM optional | deterministic fallback when `AI_API_KEY` unset |
| RAG chain (detect/classify/explain) | REAL prompt + rules | actual LLM call only with a key; otherwise rule-based |
| Speaking pronunciation score | REAL endpoint, provider optional | live with `SPEECH_API_KEY`; else deterministic fallback |
| Wallet ledger | REAL | atomic debit/credit, balance CHECK ≥ 0 |
| KYC | REAL | submit/approve flow (encrypt the ID number at rest in prod) |
| Inheritance (70 years) | REAL | `services/inheritance.js`, +70y payout window, ≤100% shares |
| Certificates SHA-256 + QR + PDF | REAL | `services/certificate.js`, public `verify.html` |
| Live sessions (Zoom / Google Meet) | REAL adapter, OAuth optional | real links with creds; else deterministic fake link |
| Phonetics hub | REAL CRUD | audio upload to S3 is the only missing piece (store URL) |
| Offline-first PWA | REAL shell | `sw.js` caches shell; outbox `POST /api/sync/flush` |
| RESEARCHER role | REAL | in enum + analytics ledger |
| Teacher curriculum + YouTube lessons | REAL (frontend) + schema | unlisted videos embedded; private cannot be embedded (YouTube rule) |
| Accredited exam booking (online / on-site) | REAL | `routes/booking.routes.js`, seats locked per transaction, online gets a proctored link, on-site assigns a center |
| Wallet UI (subscribe/top-up/payout) | REAL | ledger-backed in `routes/wallet.routes.js` |
| Specialized dashboards per role (Admin/Teacher/Student/Agent) | REAL | distinct nav + pages in `frontend/index.html` |
| Rule editing permissions | REAL | Admin edits ANY rule even after publishing; Teacher edits only own (`routes/rules.routes.js`) |
| Digital balance cards (vouchers) + QR | REAL | `services/voucher.js`, QR via `/api/vouchers/:code/qr.png`, printable |
| Sell / send voucher (SMS / WhatsApp / Email) | REAL links; SMS live optional | deep links always; Twilio SMS when `TWILIO_*` set (`services/sms.js`) |
| Redeem voucher into wallet | REAL | atomic credit in `services/voucher.js` |
| Agent application + admin approval | REAL | `routes/agent.routes.js`; approval promotes user to AGENT role |
| Agent reselling + commission | REAL | allocate to agent, mark sold, 10% commission to agent wallet |

### What genuinely needs an external paid service to go fully live
- LLM key for live RAG (`AI_API_KEY`)
- Pronunciation provider for real speaking assessment (`SPEECH_API_KEY`)
- Zoom S2S / Google OAuth for real meeting links
- S3 (or any object store) for phonetics/passport audio uploads
Each of these has a working fallback so the system runs end-to-end without them.

## API surface (selected)
```
POST /api/auth/register | /login        GET /api/auth/me
GET  /api/learn/tree
GET  /api/exam/:levelId/generate
POST /api/exam/:levelId/reading | writing | speaking | submit
POST /api/ai/check
GET/POST/DELETE /api/admin/rules        POST /api/admin/rules/benchmark
GET/POST /api/admin/phonetics | sessions
GET  /api/admin/analytics/errors | students
GET/POST /api/wallet | /api/wallet/transactions
POST /api/kyc   POST /api/kyc/:id/approve
GET/POST /api/inheritance   POST /api/inheritance/activate
POST /api/certificate/issue   GET /api/certificate/:id/pdf
GET  /api/certificate/verify/:id        (public)
GET  /api/booking/slots   POST /api/booking/slots
POST /api/booking/slots/:id/book   GET /api/booking/my   DELETE /api/booking/:id
POST /api/rules   PATCH /api/rules/:id   DELETE /api/rules/:id    (admin any / teacher own)
POST /api/vouchers   GET /api/vouchers   GET /api/vouchers/:code/qr.png
POST /api/vouchers/:id/send | /allocate | /sell    POST /api/vouchers/redeem
POST /api/agent/apply   GET /api/agent/applications   POST /api/agent/applications/:id/approve|reject
GET  /api/agent/inventory
POST /api/sync/flush                    (offline outbox)
```

## Note on verification in this environment
The author syntax-checked every backend file but could not run the full stack
here (the build sandbox has no network for `npm install` and no Postgres). It is
structured to run with `docker compose up`. Treat first run as integration test.

## Layout
```
wane/
  db/schema.sql
  backend/  (Express API, services, routes)
  frontend/ (index.html desktop, mobile.html PWA, verify.html, sw.js)
  shared/   (constants)
  docker-compose.yml  .env.example
```
