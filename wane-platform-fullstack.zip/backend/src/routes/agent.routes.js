import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { wrap } from '../middleware/error.js';
import { q } from '../db.js';

const r = Router();

// User applies to become an agent.
r.post('/apply', requireAuth, wrap(async (req, res) => {
  const { full_name, phone, region } = req.body;
  if (!full_name || !phone) return res.status(400).json({ error: 'missing_fields' });
  const existing = (await q("SELECT * FROM agent_applications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1", [req.user.sub])).rows[0];
  if (existing && existing.status === 'PENDING') return res.status(409).json({ error: 'already_pending' });
  const row = (await q(
    'INSERT INTO agent_applications (user_id, full_name, phone, region) VALUES ($1,$2,$3,$4) RETURNING *',
    [req.user.sub, full_name, phone, region || null]
  )).rows[0];
  res.status(201).json(row);
}));

r.get('/my-application', requireAuth, wrap(async (req, res) => {
  const row = (await q('SELECT * FROM agent_applications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1', [req.user.sub])).rows[0];
  res.json(row || null);
}));

// Admin reviews applications.
r.get('/applications', requireAuth, requireRole('ADMIN'), wrap(async (req, res) => {
  res.json((await q(
    `SELECT a.*, u.email FROM agent_applications a JOIN users u ON u.id=a.user_id
      WHERE a.status='PENDING' ORDER BY a.created_at`)).rows);
}));
r.post('/applications/:id/approve', requireAuth, requireRole('ADMIN'), wrap(async (req, res) => {
  const app = (await q("UPDATE agent_applications SET status='APPROVED', reviewed_by=$2 WHERE id=$1 RETURNING *", [req.params.id, req.user.sub])).rows[0];
  if (!app) return res.status(404).json({ error: 'not_found' });
  await q("UPDATE users SET role='AGENT' WHERE id=$1", [app.user_id]);   // promote
  res.json(app);
}));
r.post('/applications/:id/reject', requireAuth, requireRole('ADMIN'), wrap(async (req, res) => {
  res.json((await q("UPDATE agent_applications SET status='REJECTED', reviewed_by=$2 WHERE id=$1 RETURNING *", [req.params.id, req.user.sub])).rows[0]);
}));

// Agent inventory.
r.get('/inventory', requireAuth, requireRole('AGENT'), wrap(async (req, res) => {
  res.json((await q("SELECT * FROM vouchers WHERE owner_agent=$1 ORDER BY created_at DESC", [req.user.sub])).rows);
}));
export default r;
