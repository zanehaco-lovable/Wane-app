-- Wane platform — full PostgreSQL schema (production-oriented)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";

CREATE TYPE user_role       AS ENUM ('ADMIN','TEACHER','STUDENT','RESEARCHER');
CREATE TYPE progress_status AS ENUM ('LOCKED','UNLOCKED','COMPLETED');
CREATE TYPE tx_type         AS ENUM ('SUBSCRIPTION','PAYOUT','SHARE_DISTRIBUTION','REFUND','TOPUP');
CREATE TYPE exam_section    AS ENUM ('READING','WRITING','SPEAKING');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name VARCHAR(255) NOT NULL,
  email CITEXT UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'STUDENT',
  ui_lang VARCHAR(12) NOT NULL DEFAULT 'ckb',
  dialect VARCHAR(12) NOT NULL DEFAULT 'ckb',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE levels_and_units (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  titles JSONB NOT NULL DEFAULT '{}',
  dialect VARCHAR(50) NOT NULL,
  sort_order INT NOT NULL,
  parent_id UUID REFERENCES levels_and_units(id) ON DELETE SET NULL,
  UNIQUE (dialect, sort_order)
);

CREATE TABLE gateway_exams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  level_id UUID NOT NULL REFERENCES levels_and_units(id) ON DELETE CASCADE,
  passing_score INT NOT NULL DEFAULT 80 CHECK (passing_score BETWEEN 0 AND 100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE question_bank (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  level_id UUID NOT NULL REFERENCES levels_and_units(id) ON DELETE CASCADE,
  section exam_section NOT NULL,
  dialect VARCHAR(50) NOT NULL,
  prompt TEXT NOT NULL,
  options JSONB,
  answer_idx INT,
  weight INT NOT NULL DEFAULT 1 CHECK (weight >= 1),
  reference_audio_url VARCHAR(512),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_progress (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  node_id UUID NOT NULL REFERENCES levels_and_units(id) ON DELETE CASCADE,
  status progress_status NOT NULL DEFAULT 'LOCKED',
  best_score INT CHECK (best_score BETWEEN 0 AND 100),
  attempts INT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, node_id)
);

CREATE TABLE exam_attempts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  level_id UUID NOT NULL REFERENCES levels_and_units(id) ON DELETE CASCADE,
  reading INT, writing INT, speaking INT, total INT,
  passed BOOLEAN NOT NULL DEFAULT FALSE,
  detail JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wallets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  balance_cents BIGINT NOT NULL DEFAULT 0 CHECK (balance_cents >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE financial_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wallet_id UUID NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  amount_cents BIGINT NOT NULL,
  type tx_type NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE kyc_verification (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  identity_card_number VARCHAR(100) NOT NULL,
  passport_image_url VARCHAR(512),
  phone_number VARCHAR(50) NOT NULL,
  is_verified BOOLEAN NOT NULL DEFAULT FALSE,
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE inheritance_beneficiaries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  original_owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  beneficiary_name VARCHAR(255) NOT NULL,
  relationship VARCHAR(100) NOT NULL,
  share_percentage NUMERIC(5,2) NOT NULL CHECK (share_percentage > 0 AND share_percentage <= 100),
  payout_start_date TIMESTAMPTZ,
  payout_end_date TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ai_grammar_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  dialect VARCHAR(50) NOT NULL,
  rule_text TEXT NOT NULL,
  examples JSONB NOT NULL DEFAULT '[]',
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE phonetics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  grapheme VARCHAR(8) NOT NULL,
  dialect VARCHAR(50) NOT NULL,
  audio_url VARCHAR(512),
  tip TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE live_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  platform VARCHAR(40) NOT NULL,
  start_at TIMESTAMPTZ NOT NULL,
  duration_min INT NOT NULL DEFAULT 45,
  join_url VARCHAR(512),
  external_id VARCHAR(255),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE semantic_groups (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  concept VARCHAR(255) NOT NULL
);
CREATE TABLE semantic_words (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id UUID NOT NULL REFERENCES semantic_groups(id) ON DELETE CASCADE,
  dialect VARCHAR(50) NOT NULL,
  word VARCHAR(255) NOT NULL
);

CREATE TABLE certificates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hash_id VARCHAR(64) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  scores JSONB NOT NULL,
  pdf_url VARCHAR(512),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sync_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  op VARCHAR(60) NOT NULL,
  payload JSONB,
  client_ts TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_user_progress ON user_progress(user_id, status);
CREATE INDEX idx_levels_order ON levels_and_units(dialect, sort_order);
CREATE INDEX idx_tx_wallet ON financial_transactions(wallet_id, created_at);
CREATE INDEX idx_rules_dialect ON ai_grammar_rules(dialect);
CREATE INDEX idx_qb_level ON question_bank(level_id, section);
CREATE INDEX idx_cert_hash ON certificates(hash_id);
CREATE INDEX idx_semwords ON semantic_words(group_id);

-- Accredited certificate exam scheduling (online proctored or on-site)
CREATE TYPE exam_mode AS ENUM ('ONLINE','ONSITE');
CREATE TABLE exam_centers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  city VARCHAR(120),
  address TEXT
);
CREATE TABLE exam_slots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  level_id UUID REFERENCES levels_and_units(id) ON DELETE SET NULL,
  starts_at TIMESTAMPTZ NOT NULL,
  mode exam_mode NOT NULL DEFAULT 'ONLINE',
  center_id UUID REFERENCES exam_centers(id) ON DELETE SET NULL,
  seats INT NOT NULL DEFAULT 10 CHECK (seats > 0),
  booked INT NOT NULL DEFAULT 0 CHECK (booked >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (booked <= seats)
);
CREATE TABLE exam_bookings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slot_id UUID NOT NULL REFERENCES exam_slots(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mode exam_mode NOT NULL,
  join_url VARCHAR(512),      -- for ONLINE proctored sessions
  center_id UUID REFERENCES exam_centers(id) ON DELETE SET NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'BOOKED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (slot_id, user_id)
);
CREATE INDEX idx_slots_time ON exam_slots(starts_at);
CREATE INDEX idx_bookings_user ON exam_bookings(user_id);

-- Agent role + digital balance cards (vouchers) + agent applications
ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'AGENT';
ALTER TABLE ai_grammar_rules ADD COLUMN IF NOT EXISTS published BOOLEAN NOT NULL DEFAULT TRUE;

CREATE TYPE voucher_status AS ENUM ('ACTIVE','SOLD','REDEEMED','VOID');
CREATE TABLE vouchers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(40) UNIQUE NOT NULL,
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  status voucher_status NOT NULL DEFAULT 'ACTIVE',
  owner_agent UUID REFERENCES users(id) ON DELETE SET NULL,  -- allocated to agent
  buyer VARCHAR(255),
  redeemed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  redeemed_at TIMESTAMPTZ
);
CREATE INDEX idx_voucher_code ON vouchers(code);
CREATE INDEX idx_voucher_agent ON vouchers(owner_agent);

CREATE TYPE application_status AS ENUM ('PENDING','APPROVED','REJECTED');
CREATE TABLE agent_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  full_name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  region VARCHAR(120),
  status application_status NOT NULL DEFAULT 'PENDING',
  reviewed_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
